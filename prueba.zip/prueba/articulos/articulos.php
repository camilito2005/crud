<?php
include "./lib_articulos.php";
$opciones = $_GET["accion"];

if ($opciones == "guardar") {
    if (isset($_POST["actualizar"])) {
        Actualizar();
}
    else {
        if (!$_GET["id"]) {
        Guardar();
        }
    }

    
}

if ($opciones == "ver") {
    Ver();
}

if ($opciones == "modificar") {
    echo "modificar";
}
if($opciones == "actualizar"){
    Actualizar();
}
if($opciones == "eliminar"){
    Eliminar();
}



?>
   



