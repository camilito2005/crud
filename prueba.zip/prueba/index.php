<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="./css/formulario2.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2 class="titulo">index</h2>

    <?php
    $id = $_GET["id"];

    $opciones = $_GET["accion"];
    $nombre = $_GET["nombre"];
    $marca = $_GET["marca"];


    include "./conexion.php";
    $conexion = conexion();
    include "./articulos/lib_articulos.php";


    ?>

    <form class="formulario" action="./articulos/articulos.php?accion=guardar" method="post">
        <input class="texto" type="text" value="<?php echo $nombre ?>" id="nombre" name="name" placeholder="name">
        <input class="texto" type="text" value="<?php echo $marca ?>" id="marca" name="marca" placeholder="marca">
        <input type="hidden" name="id_arti" id="id_arti" value="<?php echo $id ?>">
        <input class="guardar" type="submit" name="submit" value="guardar">
        <input type="submit" name="actualizar" value="modificar">

    </form>


    <input type="submit" id="miBoton">

    <!-- <script>
    const boton = document.getElementById("miBoton");
    boton.addEventListener("click", function(){
        console.log("hola");
    });
    console.log("hola");
 </script>-->

        
            <?php
            ver();
            ?>
        

    <script src="./js/javascript.js">
    </script>

</body>

</html>