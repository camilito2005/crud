function Preguntas() {
  var pregunta = confirm("¿Desea eliminar el registro?");
  if (pregunta) {
    return true;
  } else {
    return false;
  }

  console.log("se elimino");
}

function Hola(id) {
  var idvalor = document.getElementById("id" + id).value;
  var nombre = document.getElementById("nombre" + id).value;
  var marca = document.getElementById("marca" + id).value;

  document.getElementById("nombre").value = nombre;
  document.getElementById("marca").value = marca;
    document.getElementById("id_arti").value = idvalor;

  console.log(idvalor, nombre, marca);
}
